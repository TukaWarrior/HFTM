# Vereinsverwaltung mit JPA (Beispiel 1: Status) #

Illustrationsbeispiel aus dem Unterricht zur Verwaltung der Vereins-Daten über JPA.
Die Lösung sollte mit dem aus dem Datenbank-Unterricht bekannten Datenbank-Container in Betrieb genommen werden.