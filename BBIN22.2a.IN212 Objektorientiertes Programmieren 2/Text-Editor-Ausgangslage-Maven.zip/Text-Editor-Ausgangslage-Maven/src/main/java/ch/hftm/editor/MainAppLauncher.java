package ch.hftm.editor;

public class MainAppLauncher {
	
	public static void main(String[] args) {
		MainApp.main(args);
	}
}